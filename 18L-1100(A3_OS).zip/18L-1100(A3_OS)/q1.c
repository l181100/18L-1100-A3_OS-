#include<stdio.h>
#include<stdlib.h>
#include <semaphore.h>
#include<pthread.h>
#include <string.h>
#include<time.h>
int potentialCpatient=0;

int testing()
{
        //srand(time(0));
	int result = rand()%2;
	if( result == 0) // corona_patient
	{			
	  return 0;
	}
	else // result == 1 ;flu_patient
	{
          return 1;
	}
}

void* potential_patient(void *param)
{
  potentialCpatient++;
  //printf("potencial patient = %d",potentialCpatient);
  int *new_ptr = NULL;
   pthread_exit( (void*) new_ptr);
}


int main()
{
    int c=0,f=0;
    sem_t Flu_Patient;
    sem_init(&Flu_Patient, 0, 1);
    sem_t CoronaPatient;
    sem_init(&CoronaPatient, 0, 1); 
    int no_of_threads=0;//potentialCPatients=0;

    printf("Enter No of Threads: ");
    scanf("%d", &no_of_threads);
    //printf("You entered: %d", no_of_threads);
    pthread_t thread_id[no_of_threads];
    int i=0;int *ptr;
    for(i=0;i<no_of_threads;i++)
    {
      if(pthread_create(&thread_id[i], NULL, potential_patient,NULL) == -1)
       {
        printf("Error:unable to create thread\n");
        exit(-1);
       }
       //printf("\nthrtead called\n");
       pthread_join(thread_id[i],NULL);
      // pthread_join(thread_id, (void**) &ptr);
       //printf("potencial = %d",potentialCpatient);
    }
    srand(time(0));
    while(potentialCpatient!=0)
    {
      int result = testing();
      if(result==1) // flu_patient
      {
      printf("\nflu patient detected");
        f++;
       sem_post(&Flu_Patient);//fluPatient will be signaled/incremented
      }
      else // corona_patient 
      {
        printf("\ncorona patient detected");
        c++;
        sem_post(&CoronaPatient); //coronaPatient will be signaled/incremented
        int check=1;
        while(check!=0)
        {
          if( testing()==1 ) //negative report
          {
             if(testing()==1) //negative report
             {
                sem_wait(&CoronaPatient);
                check=0;
                c--;
             }
             else check=1;
          }
          else check=1;
        }
      }
       potentialCpatient--;
    }
       
     sem_destroy(&CoronaPatient);
     sem_destroy(&Flu_Patient);

printf("\n\nCorona patients = %d\n",c);
printf("Flu patients    = %d\n",f);


return 0;
}
















