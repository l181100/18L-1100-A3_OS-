#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include <semaphore.h>
#include<sys/wait.h>
#include<pthread.h>
#include <string.h>

int main()
{
	char tmp[100] = "\0";
        char buff1[200] = "\0";
        char buff2[200] = "\0";	  
        FILE *fp;
  	sem_t ProcessA;
	sem_t ProcessB;
	sem_t ProcessC;
	sem_t ProcessD;
	sem_init(&ProcessA, 1, 1); 
	sem_init(&ProcessB, 1, 1);
	sem_init(&ProcessC, 1, 1); 
	sem_init(&ProcessD, 1, 1);
	
	if(fork()==0)
	{
	  sem_wait(&ProcessB);
	  fp = fopen("file1.txt","r");
	  if(fp == NULL)
	  {
            printf("file1 cannot open\n");
          }
          else
          {
             while (fgets(tmp,sizeof(tmp), fp) != NULL)
             {
               strcat(buff1,tmp);
               strcat(buff1," ");
             }
             buff1[strlen(buff1)-2] = '\0';
             printf("\nfull array=  %s", buff1);
             fclose(fp);
          }
          sem_post(&ProcessB);
	}
	else
	{
	   sem_wait(&ProcessA);
	   fp = NULL;
	   fp = fopen("file2.txt","r");
	  if(fp == NULL)
	  {
            printf("file2 cannot open\n");
          }
          else
          {
             while (fgets(tmp,sizeof(tmp), fp) != NULL)
             {
               strcat(buff1,tmp);
               strcat(buff1," ");
             }
             buff1[strlen(buff1)-2] = '\0';
             printf("\nfull array=  %s", buff1);
             fclose(fp);
          }
          sem_post(&ProcessA);
          
          if(fork()==0)
          {
            sem_wait(&ProcessA);
            sem_wait(&ProcessB);
            sem_wait(&ProcessC);
            //processC copies data of buffer1 to buffer2.
            strcpy(buff2,buff1);
            
            sem_post(&ProcessC);
            sem_post(&ProcessB);
            sem_post(&ProcessA);
          }
          else
          {
            //processD prints the message in buffer2 on screen.
            wait(NULL); //wait for all other processes to return.
            printf("\ndata in buffer2=  %s", buff2);
          }
          
          
	}
	
	sem_destroy(&ProcessA);
	sem_destroy(&ProcessB);
	sem_destroy(&ProcessC);
	sem_destroy(&ProcessD);
  return 0;
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
